export function divisao(a, b) {
    return a / b;
}

export function resto(a, b) {
    return a % b;
}
